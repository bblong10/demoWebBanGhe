<section class="myfooter bg-danger text-white py-4">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h5>DUY LONG SHOP</h5>
                <p class="m-0">Địa chỉ: 391 Điện Biên Phủ, phường 25, quận Bình Thạnh, TPHCM</p>
                <p class="m-0">Điện thoại: 0853482417 - Email: beccchanh@gmail.com</p>
            </div>
            <div class="col-md-6">
                <div>
                    <span class="box50 border border-danger mr-3 bg-dark">
                        <i class="fa-brands fa-instagram"></i>
                    </span>
                    <span class="box50 border border-danger mr-3 text-primary bg-white">
                        <i class="fa-brands fa-facebook"></i>
                    </span>
                    <span class="box50 border border-danger mr-3 bg-dark">
                        <i class="fa-brands fa-tiktok"></i>
                    </span>
                    <span class="box50 border border-danger text-danger bg-white">
                        <i class="fa-brands fa-youtube"></i>
                    </span>
                </div>
            </div>
            <hr>
            <div class="row">
                <div class="col-md text-center">Bản quyền thuộc về Duy Long Shop</div>

            </div>
        </div>
</section>